import java.util.Scanner;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("\nEnter list name:");
        String userName = scanner.nextLine();
        VSystem sys = new VSystem(userName);
        String command, time, option, year, choice, hh, type, date;
        String wro = "yes";
        List<Vocab> wrong;

        while (true) {
            System.out.println("\nEnter a command (1 add, 2 delete, 3 print all, 4 search, 5 exit, 6 start):");
            command = scanner.nextLine();
            switch (command) {
                case "1":
                    while(true){
                        System.out.println("Enter vocabulary:");
                        date = scanner.nextLine();
                        if(date.equals("sc")){
                            System.out.println("Stoped.");
                            break;
                        }
                        System.out.println("Enter Chinese:");
                        time = scanner.nextLine();
                        if (time.equals("sc")){
                                        break;
                                    }
                        System.out.println("Enter property: (if not leave it blank)");
                        hh = scanner.nextLine();
                        if (hh.equals("sc")){
                                        break;
                                    }
                        if (!sys.addVocab(date, time, hh)) {
                            System.out.println("Error! Try again!\n");
                        } else {
                            System.out.println("Done.\n");
                        }
                    }
                    break;

                case "2":
                    System.out.println("delete type: (all/one)");
                    if (scanner.nextLine().equals("all")) {
                        if (!sys.deleteAll()) {
                            System.out.println("Error! Try again!\n");
                        } else {
                            System.out.println("Done.\n");
                        }
                        break;
                    }
                    while(true){
                        System.out.println("Enter vocabulary:");
                        date = scanner.nextLine();
                        if(date.equals("sc")){
                            System.out.println("Stoped.");
                            break;
                        }
                        if (!sys.deleteVocab(date)) {
                            System.out.println("Error! Try again!\n");
                        } else {
                            System.out.println("Done.\n");
                        }
                    }
                    break;
                case "3":
                    System.out.println("\nVocabulary\t\tChinese\t\t\t\t\tproperty");
                    System.out.println("**********************************************");
                    if (!sys.printVocab()) {
                        System.out.println("No Events!\n");
                    }
                    break;
                case "4":
                    System.out.println("Search by: (1 vocab, 2 Chinese)");
                    option = scanner.nextLine();
                    switch (option) {
                        case "1":
                            while (true) {
                                System.out.println("Enter vocab:");
                                year = scanner.nextLine();
                                if (year.equals("sc")){
                                    System.out.println("Stoped.");
                                    break;
                                }
                                if (!sys.searchVocab(year)) {
                                    System.out.println("No Events!\n");
                                }
                                System.out.println();
                            }
                            break;
                        case "2":
                            while (true) {
                                System.out.println("Enter Chinese:");
                                year = scanner.nextLine();
                                if (year.equals("sc")){
                                    System.out.println("Stoped.");
                                    break;
                                }
                                if (!sys.searchChinese(year)) {
                                    System.out.println("No Events!\n");
                                }
                                System.out.println();
                            }
                            break;
                        default:
                            System.out.println("Invalid Input. Please try again.");
                            System.out.println();
                            break;
                    }
                    break;
                case "5":
                    scanner.close();
                    return;
                case "6":
                    System.out.println("Mode: (1 test, 2 flashcard)");
                    option = scanner.nextLine();
                    System.out.println("Type: (1 中译英, 2 英译中)");
                    type = scanner.nextLine();
                    if (option.equals("1")) {
                        System.out.println("Start by: (1 正序, 2 倒序, 3 随机)");
                        choice = scanner.nextLine();
                        if (type.equals("1")) {
                            sys.game1(choice);
                            System.out.println("Want to do the wrong again? (yes/no)");
                            wro = scanner.nextLine();
                            while(wro.equals("yes")){

                                for (int i = sys.getWrongs().size()-1; i>=0; i--){
                                    System.out.println("\n"+sys.getWrongs().get(i).getChinese());
                                    String a = scanner.nextLine();
                                    if (a.equals("sc")){
                                        break;
                                    }
                                    if (!sys.checkCNtoEN(sys.getWrongs().get(i).getChinese(), a)) {
                                        System.out.println("Incorrect!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                    } 
                                    else {
                                        System.out.println("Good! Correct!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                        sys.getWrongs().remove(i);
                                    }
                                }
                                wrong = sys.getWrongs();
                                System.out.println("\nWrong Again List: ");
                                for (Vocab voc: wrong){
                                    System.out.println(voc);
                                }
                                if(wrong.isEmpty()){
                                    System.out.print("\nCongrats! All correct!\n");
                                    break;
                                }
                                System.out.println("Want to do the wrong again? (yes/no)");
                                wro = scanner.nextLine();
                            }
                        }
                        else if(type.equals("2")){
                            sys.game2(choice);
                            System.out.println("Want to do the wrong again? (yes/no)");
                            wro = scanner.nextLine();
                            while(wro.equals("yes")){
                                for (int i = sys.getWrongs().size()-1; i>=0; i--){
                                    System.out.println("\n"+sys.getWrongs().get(i).getVocab());
                                    String a = scanner.nextLine();
                                    if (a.equals("sc")){
                                        break;
                                    }
                                    if (!sys.checkENtoCN(sys.getWrongs().get(i).getVocab(), a)) {
                                        System.out.println("Incorrect!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                    } 
                                    else {
                                        System.out.println("Good! Correct!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                        sys.getWrongs().remove(i);
                                    }
                                }
                                wrong = sys.getWrongs();
                                if(wrong.isEmpty()){
                                    System.out.print("\nCongrats! All correct!\n");
                                    break;
                                }
                                else{
                                    System.out.println("\nWrong Again List: ");
                                    for (Vocab voc:wrong){
                                        System.out.println(voc);
                                    }

                                    System.out.println("\nWant to do the wrong again? (yes/no)");
                                    wro = scanner.nextLine();
                                }
                            }
                        }

                    } else if (option.equals("2")) {
                        System.out.println("Start by: (1 正序, 2 倒序, 3 随机)");
                        choice = scanner.nextLine();
                        sys.game3(choice, type);
                        System.out.println("Want to do the wrong again? (yes/no)");
                        wro = scanner.nextLine();
                        while(wro.equals("yes")){
                            if (type.equals("1")){
                                for (int i = sys.getWrongs().size()-1; i>=0; i--){
                                    System.out.println("\n"+sys.getWrongs().get(i).getChinese());
                                    String a = scanner.nextLine();
                                    if (a.equals("sc")){
                                        break;
                                    }
                                    if (a.equals("x")) {
                                        System.out.println("Check!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                    } 
                                    else {
                                        System.out.println("Good!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                        sys.getWrongs().remove(i);
                                    }
                                }
                                wrong = sys.getWrongs();
                                System.out.println("\nWrong Again List: ");
                                for (Vocab voc: wrong){
                                    System.out.println(voc);
                                }
                                if(wrong.isEmpty()){
                                    System.out.print("\nCongrats! All correct!\n");
                                    break;
                                }
                                System.out.println("Want to do the wrong again? (yes/no)");
                                wro = scanner.nextLine();
                            }

                            else if (type.equals("2")){
                                for (int i = sys.getWrongs().size()-1; i>=0; i--){
                                    System.out.println("\n"+sys.getWrongs().get(i).getVocab());
                                    String a = scanner.nextLine();
                                    if (a.equals("sc")){
                                        break;
                                    }
                                    if (a.equals("x")) {
                                        System.out.println("Check!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                    } 
                                    else {
                                        System.out.println("Good!");
                                        System.out.println("Right Answer: " + sys.getWrongs().get(i));
                                        sys.getWrongs().remove(i);
                                    }
                                    }
                                }
                                wrong = sys.getWrongs();
                                if(wrong.isEmpty()){
                                    System.out.print("\nCongrats! All correct!\n");
                                    break;
                                }
                                else{
                                    System.out.println("\nWrong Again List: ");
                                    for (Vocab voc:wrong){
                                        System.out.println(voc);
                                    }

                                    System.out.println("\nWant to do the wrong again? (yes/no)");
                                    wro = scanner.nextLine();
                                }
                            }}
                    
                    break;
                default:
                    System.out.println("Invalid command. Please try again.\n");
                    break;
            }
        }
    }
}