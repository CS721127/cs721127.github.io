import java.io.*;
import java.util.*;

class Vocab implements Serializable {
    private static final long serialVersionUID = 1L;
    private String vocab; 
    private String chinese, property; 

    public Vocab(String vocab, String chinese, String property) {
        this.chinese = chinese;
        this.vocab = vocab;
        this.property = property;
    }

    public String getVocab() {
        return vocab;
    }

    public String getChinese() {
        return chinese;
    }
    
    public String getProperty() {
        return property;
    }

    @Override
    public String toString() {
        return vocab + "\t\t\t" + chinese+"\t\t\t\t\t"+property;
    }
}