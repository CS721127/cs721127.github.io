import java.io.*;
import java.util.*;

class VSystem {
    private List<Vocab> vocabs;
    private String fileName;
    private List<Integer> check;
    private List<Vocab> wrong;
    private Scanner scan;

    public VSystem(String VocabList) {
        this.fileName = VocabList + "_events.dat";
        vocabs = new ArrayList<>();
        loadEvents();
        scan = new Scanner(System.in);
    }

    public boolean addVocab(String vocab, String chinese, String property) {
        boolean b = vocabs.add(new Vocab(vocab, chinese, property));
        saveEvents();
        return b;
    }

    public boolean deleteVocab(String vocab) {
        boolean a = vocabs.removeIf(event -> event.getVocab().equals(vocab));
        saveEvents();
        return a;
    }

    public boolean printVocab() {
        boolean a = false;
        for (Vocab voc : vocabs) {
            if (voc.getVocab() != null) {
                System.out.println(voc);
                a = true;
            }
        }
        return a;
    }

    public boolean deleteAll() {
        vocabs.clear();
        saveEvents();
        return vocabs.isEmpty();
    }

    public boolean searchVocab(String voc) {
        boolean a = false;
        for (Vocab vocab : vocabs) {
            if (vocab.getVocab().contains(voc)) {
                System.out.println(vocab);
                a = true;
            }
        }
        return a;
    }

    public boolean searchG(String voc) {
        boolean a = false;
        for (Vocab vocab : vocabs) {
            if (vocab.getVocab().contains(voc)) {
                System.out.println(vocab);
                a = true;
            }
        }
        return a;
    }

    public boolean searchChinese(String chi) {
        boolean a = false;
        for (Vocab vocab : vocabs) {
            if (vocab.getChinese().contains(chi)) {
                System.out.println(vocab);
                a = true;
            }
        }
        return a;
    }

    public boolean checkCNtoEN(String Chinese, String English) {
        for (Vocab vocab : vocabs) {
            if (vocab.getChinese().equals(Chinese) && vocab.getVocab().equals(English)) {
                return true;
            }
        }
        return false;
    }

    public boolean checkENtoCN(String English, String Chinese) {
        for (Vocab vocab : vocabs) {
            if (vocab.getVocab().toLowerCase().equals(English.toLowerCase()) && vocab.getChinese().contains(Chinese)) {
                return true;
            }
        }
        return false;
    }

    public void game1(String mode) { //zhongyiying
        wrong = new ArrayList<>();
        check = new ArrayList<>();
        String a;
        if (mode.equals("1")) { // zhengxu
            for (int i = 0; i < vocabs.size(); i++) {
                System.out.println("\n"+vocabs.get(i).getChinese()+"\t"+vocabs.get(i).getProperty());
                a = scan.nextLine();
                if (a.equals("sc")){
                    break;
                }
                if (checkCNtoEN(vocabs.get(i).getChinese(), a)) {
                    System.out.println("Good! Correct!");
                } else {
                    wrong.add(vocabs.get(i));
                    System.out.println("Incorrect!");
                }
                System.out.println("Right Answer: " + vocabs.get(i));
            }
        } else if (mode.equals("2")) { // daoxu
            for (int i = vocabs.size() - 1; i >= 0; i--) {
                System.out.println("\n"+vocabs.get(i).getChinese()+"\t"+vocabs.get(i).getProperty());
                a = scan.nextLine();
                if (a.equals("sc")){
                    break;
                }
                if (checkCNtoEN(vocabs.get(i).getChinese(), a)) {
                    System.out.println("Good! Correct!");
                } else {
                    wrong.add(vocabs.get(i));
                    System.out.println("Incorrect!");
                }
                System.out.println("Right Answer: " + vocabs.get(i));
            }
        } else { // suiji
            Random r = new Random();
            while (check.size() < vocabs.size()) {
                int b = r.nextInt(vocabs.size());
                if (!check.contains(b)) {
                    check.add(b);
                    System.out.println("\n"+vocabs.get(b).getChinese()+"\t"+vocabs.get(b).getProperty());
                    a = scan.nextLine();
                    if (a.equals("sc")){
                        break;
                    }
                    if (checkCNtoEN(vocabs.get(b).getChinese(), a)) {
                        System.out.println("Good! Correct!");
                    } else {
                        wrong.add(vocabs.get(b));
                        System.out.println("Incorrect!");
                    }
                    System.out.println("Right Answer: " + vocabs.get(b));
                }
            }
        }
        System.out.println("\nWrong: ");
        if (wrong.isEmpty()){
            System.out.println("N/A");
        }
        else {
            for (Vocab voc : wrong) {
                if (voc.getVocab() != null) {
                    System.out.println(voc);
                }
            }
        }
    }

    public void game2(String mode) { //yingyizhong
        wrong = new ArrayList<>();
        check = new ArrayList<>();
        String c;
        if (mode.equals("1")) { // zhengxu
            for (int i = 0; i < vocabs.size(); i++) {
                System.out.println("\n"+vocabs.get(i).getVocab()+"\t"+vocabs.get(i).getProperty());
                c = scan.nextLine();
                if (c.equals("sc")){
                    break;
                }
                if (checkENtoCN(vocabs.get(i).getVocab(), c)) {
                    System.out.println("Good! Correct!");
                } else {
                    wrong.add(vocabs.get(i));
                    System.out.println("Incorrect!");
                }
                System.out.println("Right Answer: " + vocabs.get(i));
            }
        } else if (mode.equals("2")) { // daoxu
            for (int i = vocabs.size() - 1; i >= 0; i--) {
                System.out.println("\n"+vocabs.get(i).getVocab()+"\t"+vocabs.get(i).getProperty());
                c = scan.nextLine();
                if (c.equals("sc")){
                    break;
                }
                if (checkENtoCN(vocabs.get(i).getVocab(), c)) {
                    System.out.println("Good! Correct!");
                } else {
                    wrong.add(vocabs.get(i));
                    System.out.println("Incorrect!");
                }
                System.out.println("Right Answer: " + vocabs.get(i));
            }
        } else { // suiji
            Random r = new Random();
            while (check.size() < vocabs.size()) {
                int b = r.nextInt(vocabs.size());
                if (!check.contains(b)) {
                    check.add(b);
                    System.out.println("\n"+vocabs.get(b).getVocab()+"\t"+vocabs.get(b).getProperty());
                    c = scan.nextLine();
                    if (c.equals("sc")){
                        break;
                    }
                    if (checkENtoCN(vocabs.get(b).getVocab(), c)) {
                        System.out.println("Good! Correct!");
                    } else {
                        wrong.add(vocabs.get(b));
                        System.out.println("Incorrect!");
                    }
                    System.out.println("Right Answer: " + vocabs.get(b));
                }
            }
        }
        System.out.println("\nWrong: ");
        if (wrong.isEmpty()){
            System.out.print("N/A");
        }
        else {
            for (Vocab voc : wrong) {
                if (voc.getVocab() != null) {
                    System.out.println(voc);
                }
            }
        }

    }

    public void game3(String mode, String choice) { //flashcard
        wrong = new ArrayList<>();
        check = new ArrayList<>();
        String a;
        switch (mode) {
            case "1": // zhengxu
                if (choice.equals("2")) { // yingyizhong
                    for (int i = 0; i < vocabs.size(); i++) {
                        System.out.println("\n"+vocabs.get(i).getVocab());
                        a = scan.nextLine();
                        if (a.equals("x")) {
                            wrong.add(vocabs.get(i));
                        }
                        if (a.equals("sc")){
                            break;
                        }
                        System.out.println("Right Answer: " + vocabs.get(i));
                    }
                } else { // zhongyiying
                    for (int i = 0; i < vocabs.size(); i++) {
                        System.out.println("\n"+vocabs.get(i).getChinese());
                        a = scan.nextLine();
                        if (a.equals("x")) {
                            wrong.add(vocabs.get(i));
                        }
                        if (a.equals("sc")){
                            break;
                        }
                        System.out.println("Right Answer: " + vocabs.get(i));
                    }
                }
                System.out.println("\nCheck: ");
                if (wrong.isEmpty()){
                    System.out.println("N/A");
                }
                else {
                    for (Vocab voc : wrong) {
                        if (voc.getVocab() != null) {
                            System.out.println(voc);
                        }
                    }
                }

                break;
            case "2": // daoxu
                if (choice.equals("2")) { // yingyizhong
                    for (int i = vocabs.size() - 1; i >= 0; i--) {
                        System.out.println("\n"+vocabs.get(i).getVocab());
                        a = scan.nextLine();
                        if (a.equals("x")) {
                            wrong.add(vocabs.get(i));
                        }
                        if (a.equals("sc")){
                            break;
                        }
                        System.out.println("Right Answer: " + vocabs.get(i));
                    }
                } else { // zhongyiying
                    for (int i = vocabs.size() - 1; i >= 0; i--) {
                        System.out.println("\n"+vocabs.get(i).getChinese());
                        a = scan.nextLine();
                        if (a.equals("x")) {
                            wrong.add(vocabs.get(i));
                        }
                        if (a.equals("sc")){
                            break;
                        }
                        System.out.println("Right Answer: " + vocabs.get(i));
                    }
                }
                System.out.println("\nCheck: ");
                if (wrong.isEmpty()){
                    System.out.print("N/A");
                }
                else {
                    for (Vocab voc : wrong) {
                        if (voc.getVocab() != null) {
                            System.out.println(voc);
                        }
                    }
                }

                break;
            case "3": // suiji
                Random r = new Random();
                while (check.size() < vocabs.size()) {
                    int b = r.nextInt(vocabs.size());
                    if (!check.contains(b)) {
                        check.add(b);
                        if (choice.equals("2")) { // yingyizhong
                            System.out.println("\n"+vocabs.get(b).getVocab());
                        } else { // zhongyiying
                            System.out.println("\n"+vocabs.get(b).getChinese());
                        }
                        a = scan.nextLine();
                        if (a.equals("x")) {
                            wrong.add(vocabs.get(b));
                        }
                        if (a.equals("sc")){
                            break;
                        }
                        System.out.println("Right Answer: " + vocabs.get(b));
                    }
                }
                System.out.println("\nCheck: ");
                if (wrong.isEmpty()){
                    System.out.print("N/A");
                }
                else {
                    for (Vocab voc : wrong) {
                        if (voc.getVocab() != null) {
                            System.out.println(voc);
                        }
                    }
                }

                break;
        }
    }

    public List<Vocab> getVocabs(){
        return vocabs;
    }

    public List<Vocab> getWrongs(){
        return wrong;
    }

    private void saveEvents() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(fileName))) {
            oos.writeObject(vocabs);
        } catch (IOException e) {
            System.out.println("Error saving events: " + e.getMessage());
        }
    }

    private void loadEvents() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(fileName))) {
            vocabs = (ArrayList<Vocab>) ois.readObject();
        } catch (FileNotFoundException e) {
            // File not found, nothing to load
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Error loading events: " + e.getMessage());
        }
    }
}